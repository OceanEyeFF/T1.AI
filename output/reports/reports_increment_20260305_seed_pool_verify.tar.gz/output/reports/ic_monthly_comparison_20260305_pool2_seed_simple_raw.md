# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_pool2_etf58_auto_window24_seq20_w010_045_045_icaware_a0176_seed042_20260305.json | daily_cs | 0.1250 | 0.1250 | 50.0% | -0.1818 | 1 | FAIL |
| lstm_pool2_etf58_auto_window24_seq20_w010_045_045_icaware_a0176_seed099_20260305.json | daily_cs | -0.1528 | -0.1528 | 33.3% | -0.6500 | 3 | FAIL |
