# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 3/3 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_20260305.json | daily_cs | 0.0595 | 0.0805 | 66.7% | -0.4264 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_seed007_20260305.json | daily_cs | -0.1621 | -0.1341 | 16.7% | -0.3397 | 5 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_seed099_20260305.json | daily_cs | -0.0687 | -0.0225 | 33.3% | -0.1724 | 3 | FAIL |
