# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 7/7 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim44_drop_new12_auto_window24_l1_20260304.json | daily_cs | -0.0214 | -0.0437 | 50.0% | -0.2426 | 1 | FAIL |
| lstm_dim48_no_mf_momma_auto_window24_l1_20260304.json | daily_cs | -0.0319 | -0.0356 | 66.7% | -0.6342 | 2 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_l1_20260304.json | daily_cs | -0.0089 | 0.0344 | 50.0% | -0.4008 | 1 | FAIL |
| lstm_dim53_nohist_volvol_auto_window24_l1_20260304.json | daily_cs | -0.0792 | -0.0483 | 16.7% | -0.2704 | 3 | FAIL |
| lstm_dim56_auto_window24_l1_20260304_histflow.json | daily_cs | -0.1231 | -0.0920 | 16.7% | -0.5083 | 3 | FAIL |
| lstm_dim58_auto_window24_l1_20260304.json | daily_cs | 0.0210 | 0.0226 | 66.7% | -0.1069 | 1 | FAIL |
| lstm_dim58_nohist_etf_auto_window24_l1_20260304.json | daily_cs | -0.0372 | -0.0432 | 33.3% | -0.1653 | 3 | FAIL |
