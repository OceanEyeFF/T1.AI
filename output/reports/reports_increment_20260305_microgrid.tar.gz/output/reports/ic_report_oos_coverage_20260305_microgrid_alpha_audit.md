# IC 报告 OOS 覆盖率审计

- 报告总数: 3
- 有 OOS parquet 路径: 3
- strict daily-CS(raw) 就绪: 3
- strict daily-CS(calibrated) 就绪: 3

| 报告 | OOS 路径 | raw列 | cal列 | 样本行数 | 月份数 | 问题 |
|---|---|---|---|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a010_20260304.json | YES | YES | YES | 864 | 6 | OK |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a008_20260305.json | YES | YES | YES | 864 | 6 | OK |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a012_20260305.json | YES | YES | YES | 864 | 6 | OK |
