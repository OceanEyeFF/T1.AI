# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 7/7 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim44_drop_new12_auto_window24_l1_20260304.json | daily_cs | 0.0410 | 0.0351 | 66.7% | -0.1059 | 1 | FAIL |
| lstm_dim48_no_mf_momma_auto_window24_l1_20260304.json | daily_cs | 0.0043 | -0.0338 | 66.7% | -0.6342 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_l1_20260304.json | daily_cs | 0.0575 | 0.0761 | 66.7% | -0.0341 | 1 | FAIL |
| lstm_dim53_nohist_volvol_auto_window24_l1_20260304.json | daily_cs | -0.0370 | -0.0421 | 33.3% | -0.1358 | 2 | FAIL |
| lstm_dim56_auto_window24_l1_20260304_histflow.json | daily_cs | -0.0248 | -0.0409 | 33.3% | -0.5083 | 3 | FAIL |
| lstm_dim58_auto_window24_l1_20260304.json | daily_cs | -0.0073 | 0.0078 | 50.0% | -0.2055 | 2 | FAIL |
| lstm_dim58_nohist_etf_auto_window24_l1_20260304.json | daily_cs | 0.0358 | 0.0529 | 50.0% | -0.0624 | 2 | FAIL |
