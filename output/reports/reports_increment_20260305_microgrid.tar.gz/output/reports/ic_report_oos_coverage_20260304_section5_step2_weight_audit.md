# IC 报告 OOS 覆盖率审计

- 报告总数: 3
- 有 OOS parquet 路径: 3
- strict daily-CS(raw) 就绪: 3
- strict daily-CS(calibrated) 就绪: 3

| 报告 | OOS 路径 | raw列 | cal列 | 样本行数 | 月份数 | 问题 |
|---|---|---|---|---:|---:|---|
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_w100_100_100.json | YES | YES | YES | 864 | 6 | OK |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_w020_040_040.json | YES | YES | YES | 864 | 6 | OK |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_w010_045_045.json | YES | YES | YES | 864 | 6 | OK |
