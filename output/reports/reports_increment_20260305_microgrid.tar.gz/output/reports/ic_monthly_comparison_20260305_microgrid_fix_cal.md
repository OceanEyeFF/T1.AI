# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 5/5 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a010_20260304.json | daily_cs | 0.1146 | 0.1265 | 83.3% | -0.1132 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a010_cm2_st002_20260305.json | daily_cs | 0.1146 | 0.1265 | 83.3% | -0.1132 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a010_cm4_st002_20260305.json | daily_cs | 0.1146 | 0.1265 | 83.3% | -0.1132 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a010_cm2_st003_20260305.json | daily_cs | 0.0295 | 0.0507 | 66.7% | -0.2394 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a010_cm4_st003_20260305.json | daily_cs | 0.0295 | 0.0507 | 66.7% | -0.2394 | 1 | FAIL |
