# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 8/8 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim19_window24_horizoncal_consensus_seq20_20260304_w010_045_045.json | daily_cs | -0.0543 | -0.0403 | 50.0% | -0.2007 | 3 | FAIL |
| lstm_dim19_window24_horizoncal_consensus_seq20_20260304_w010_045_045_icrank.json | daily_cs | 0.0492 | -0.0291 | 83.3% | -0.0188 | 1 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_icaware_a010.json | daily_cs | 0.0548 | -0.0065 | 83.3% | -0.0312 | 1 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_icaware_a020.json | daily_cs | -0.0087 | -0.0653 | 83.3% | -0.2758 | 1 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_rankaware_a010.json | daily_cs | -0.0152 | -0.0527 | 50.0% | -0.2241 | 3 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_rankaware_a020.json | daily_cs | -0.0226 | -0.0369 | 33.3% | -0.2214 | 4 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_rankaware_a030.json | daily_cs | -0.0720 | -0.0571 | 33.3% | -0.2361 | 4 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_icrank_a020_b020.json | daily_cs | -0.0417 | -0.0637 | 66.7% | -0.2496 | 2 | FAIL |
