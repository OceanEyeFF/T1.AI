# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 3/3 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window12_l1_20260304_w010_045_045.json | daily_cs | 0.0018 | -0.0087 | 50.0% | -0.2047 | 2 | FAIL |
| lstm_dim52_no_hist_hl_auto_window18_l1_20260304_w010_045_045.json | daily_cs | -0.0202 | 0.0052 | 50.0% | -0.1539 | 2 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_l1_20260304.json | daily_cs | -0.0089 | 0.0344 | 50.0% | -0.4008 | 1 | FAIL |
