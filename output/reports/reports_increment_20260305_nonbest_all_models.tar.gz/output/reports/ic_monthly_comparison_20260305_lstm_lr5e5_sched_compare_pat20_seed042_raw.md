# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 4/4 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_20260305.json | daily_cs | 0.0595 | 0.0805 | 66.7% | -0.4264 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_seed042_20260305.json | daily_cs | 0.0222 | 0.0269 | 50.0% | -0.4322 | 2 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_cosine_t20_seed042_20260305.json | daily_cs | 0.0159 | 0.0244 | 50.0% | -0.4166 | 2 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_seed042_20260305.json | daily_cs | 0.0231 | 0.0347 | 66.7% | -0.5545 | 1 | FAIL |
