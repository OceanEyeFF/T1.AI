# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 13/13 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_20260305.json | daily_cs | 0.1025 | 0.1023 | 66.7% | -0.0948 | 1 | PASS |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr1e5_seed042_20260305.json | daily_cs | -0.0119 | 0.0196 | 33.3% | -0.2042 | 4 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr1e5_unlim_pat20_seed042_20260305.json | daily_cs | 0.0531 | 0.0798 | 33.3% | -0.2042 | 4 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_cosine_t20_seed042_20260305.json | daily_cs | 0.1239 | 0.1185 | 66.7% | -0.0665 | 2 | PASS |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_adam_rmsnorm_gc05_seed042_20260305.json | daily_cs | 0.1635 | 0.1496 | 83.3% | -0.0129 | 1 | PASS |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_seed007_20260305.json | daily_cs | 0.0670 | 0.0538 | 66.7% | -0.0962 | 1 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_seed042_20260305.json | daily_cs | 0.1668 | 0.1685 | 83.3% | -0.0164 | 1 | PASS |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_seed099_20260305.json | daily_cs | -0.0475 | -0.0250 | 33.3% | -0.1117 | 4 | FAIL |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_seed042_20260305.json | daily_cs | 0.1342 | 0.1263 | 66.7% | -0.0278 | 2 | PASS |
| transformer_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_dm64_h4_l2_ff128_do025_lr1e5_seed042_20260305.json | daily_cs | -0.0045 | 0.0118 | 33.3% | -0.1006 | 3 | FAIL |
| transformer_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_dm64_h4_l2_ff128_do025_lr2e4_seed042_20260305.json | daily_cs | 0.0068 | 0.0158 | 50.0% | -0.4170 | 3 | FAIL |
| transformer_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_dm64_h4_l2_ff128_do025_lr5e5_unlim_coswrt_t08_m2_pat20_adam_rmsnorm_gc05_seed042_20260305.json | daily_cs | 0.0097 | 0.0351 | 66.7% | -0.1770 | 2 | FAIL |
| xgboost_dim52_no_hist_hl_auto_window24_seq20_ne500_md6_lr003_ss08_cs08_es40_seed042_20260305.json | daily_cs | -0.0871 | -0.0709 | 16.7% | -0.2294 | 5 | FAIL |
