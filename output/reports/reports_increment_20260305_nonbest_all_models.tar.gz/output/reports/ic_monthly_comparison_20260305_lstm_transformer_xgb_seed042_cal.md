# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 3/3 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_adam_rmsnorm_gc05_seed042_20260305.json | daily_cs | 0.1635 | 0.1496 | 83.3% | -0.0129 | 1 | PASS |
| transformer_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_dm64_h4_l2_ff128_do025_lr5e5_unlim_coswrt_t08_m2_pat20_adam_rmsnorm_gc05_seed042_20260305.json | daily_cs | 0.0097 | 0.0351 | 66.7% | -0.1770 | 2 | FAIL |
| xgboost_dim52_no_hist_hl_auto_window24_seq20_ne500_md6_lr003_ss08_cs08_es40_seed042_20260305.json | daily_cs | -0.0871 | -0.0709 | 16.7% | -0.2294 | 5 | FAIL |
