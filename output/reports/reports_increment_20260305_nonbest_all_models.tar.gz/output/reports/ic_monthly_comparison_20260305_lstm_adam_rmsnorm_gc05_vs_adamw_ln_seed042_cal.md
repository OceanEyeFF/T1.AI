# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_seed042_20260305.json | daily_cs | 0.1668 | 0.1685 | 83.3% | -0.0164 | 1 | PASS |
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_lr5e5_unlim_coswrt_t08_m2_pat20_adam_rmsnorm_gc05_seed042_20260305.json | daily_cs | 0.1635 | 0.1496 | 83.3% | -0.0129 | 1 | PASS |
