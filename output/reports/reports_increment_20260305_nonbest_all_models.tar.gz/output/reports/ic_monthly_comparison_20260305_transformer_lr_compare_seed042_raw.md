# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 3/3 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_20260305.json | daily_cs | 0.0595 | 0.0805 | 66.7% | -0.4264 | 1 | FAIL |
| transformer_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_dm64_h4_l2_ff128_do025_lr2e4_seed042_20260305.json | daily_cs | 0.0016 | 0.0056 | 50.0% | -0.4008 | 2 | FAIL |
| transformer_dim52_no_hist_hl_auto_window24_seq20_w010_045_045_icaware_a0176_dm64_h4_l2_ff128_do025_lr1e5_seed042_20260305.json | daily_cs | 0.0522 | 0.0603 | 50.0% | -0.0876 | 2 | FAIL |
