# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim44_compact_window24_l1_nonqfq_20260304.json | daily_cs | -0.0545 | -0.0973 | 33.3% | -0.2290 | 2 | FAIL |
| lstm_dim44_compact_window24_l1_qfq_20260304.json | daily_cs | 0.0410 | 0.0351 | 66.7% | -0.1059 | 1 | FAIL |
