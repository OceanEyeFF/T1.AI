# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim58_auto_window24_l1_20260304.json | daily_cs | 0.0210 | 0.0226 | 66.7% | -0.1069 | 1 | FAIL |
| lstm_dim56_auto_window24_l1_20260304_histflow.json | daily_cs | -0.1231 | -0.0920 | 16.7% | -0.5083 | 3 | FAIL |
