# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 3/3 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_w020_040_040.json | daily_cs | -0.0279 | -0.0907 | 66.7% | -0.2946 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_w010_045_045.json | daily_cs | -0.0239 | -0.0849 | 66.7% | -0.2861 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_w100_100_100.json | daily_cs | -0.0457 | -0.0985 | 33.3% | -0.3306 | 3 | FAIL |
