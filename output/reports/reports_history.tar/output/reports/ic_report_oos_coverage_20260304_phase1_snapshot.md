# IC 报告 OOS 覆盖率审计

- 报告总数: 14
- 有 OOS parquet 路径: 0
- strict daily-CS(raw) 就绪: 0
- strict daily-CS(calibrated) 就绪: 0

| 报告 | OOS 路径 | raw列 | cal列 | 样本行数 | 月份数 | 问题 |
|---|---|---|---|---:|---:|---|
| lstm_dim19_h2_rolling18m_seq20_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_dim19_h2_rolling18m_seq30_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_dim19_rolling18m_horizoncal_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_dim19_rolling18m_horizoncal_consensus_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_dim19_rolling18m_horizoncal_consensus_seq40_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_dim19_rolling18m_horizoncal_consensus_seq60_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_sector70_dim11_vs_16_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_sector70_dim16_param_sweep_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_sector70_dim16_vs_dim19_mkt_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_sector70_dim_compare_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_sector_experiment_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_walkforward_sign_calibration_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
| lstm_walkforward_sign_calibration_dim19_mkt_20260303.json | NO | NO | NO | 0 | 0 | missing_oos_path |
