# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim44_compact_window24_l1_nonqfq_20260304.json | daily_cs | -0.0554 | -0.0984 | 50.0% | -0.2290 | 1 | FAIL |
| lstm_dim44_compact_window24_l1_qfq_20260304.json | daily_cs | -0.0214 | -0.0437 | 50.0% | -0.2426 | 1 | FAIL |
