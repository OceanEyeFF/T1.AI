# IC 统一评估比较

- 指标口径: calibrated
- 月度口径: calibrated
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim52_no_hist_hl_auto_window24_l1_20260304.json | daily_cs | 0.0575 | 0.0761 | 66.7% | -0.0341 | 1 | FAIL |
| lstm_dim53_nohist_volvol_auto_window24_l1_20260304.json | daily_cs | -0.0370 | -0.0421 | 33.3% | -0.1358 | 2 | FAIL |
