# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 8/8 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim19_window24_horizoncal_consensus_seq20_20260304_w010_045_045.json | daily_cs | -0.0004 | -0.0456 | 66.7% | -0.2007 | 2 | FAIL |
| lstm_dim19_window24_horizoncal_consensus_seq20_20260304_w010_045_045_icrank.json | daily_cs | 0.0129 | -0.0639 | 83.3% | -0.2674 | 1 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_icaware_a020.json | daily_cs | -0.0068 | -0.0688 | 83.3% | -0.2758 | 1 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_icaware_a010.json | daily_cs | 0.0150 | -0.0638 | 83.3% | -0.2766 | 1 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_rankaware_a020.json | daily_cs | 0.0223 | -0.0263 | 50.0% | -0.2214 | 3 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_rankaware_a010.json | daily_cs | -0.0066 | -0.0496 | 50.0% | -0.2241 | 3 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_rankaware_a030.json | daily_cs | -0.0094 | -0.0631 | 66.7% | -0.2361 | 2 | FAIL |
| lstm_dim19_window24_seq20_w010_045_045_icrank_a020_b020.json | daily_cs | -0.0371 | -0.0617 | 66.7% | -0.2496 | 2 | FAIL |
