# IC 报告 OOS 覆盖率审计

- 报告总数: 2
- 有 OOS parquet 路径: 2
- strict daily-CS(raw) 就绪: 2
- strict daily-CS(calibrated) 就绪: 2

| 报告 | OOS 路径 | raw列 | cal列 | 样本行数 | 月份数 | 问题 |
|---|---|---|---|---:|---:|---|
| lstm_dim26_auto_window24_l1_20260304.json | YES | YES | YES | 864 | 6 | OK |
| lstm_dim58_auto_window24_l1_20260304.json | YES | YES | YES | 864 | 6 | OK |
