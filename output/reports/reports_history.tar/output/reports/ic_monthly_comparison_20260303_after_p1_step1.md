# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 0/2 份报告
- 公共 OOS 月份数: 10

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim19_h2_rolling18m_seq20_20260303.json | report_metrics | 0.0603 | 0.0564 | 40.0% | -0.2143 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260303.json | report_metrics | 0.0672 | 0.1100 | 40.0% | -0.2174 | 2 | FAIL |
