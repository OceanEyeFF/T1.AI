# IC 报告 OOS 覆盖率审计

- 报告总数: 2
- 有 OOS parquet 路径: 2
- strict daily-CS(raw) 就绪: 2
- strict daily-CS(calibrated) 就绪: 2

| 报告 | OOS 路径 | raw列 | cal列 | 样本行数 | 月份数 | 问题 |
|---|---|---|---|---:|---:|---|
| lstm_dim19_window24_horizoncal_consensus_seq20_20260304_w010_045_045.json | YES | YES | YES | 864 | 6 | OK |
| lstm_dim19_window24_horizoncal_consensus_seq20_20260304_w010_045_045_icrank.json | YES | YES | YES | 864 | 6 | OK |
