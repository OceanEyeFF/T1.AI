# IC 报告 OOS 覆盖率审计

- 报告总数: 2
- 有 OOS parquet 路径: 2
- strict daily-CS(raw) 就绪: 2
- strict daily-CS(calibrated) 就绪: 1

| 报告 | OOS 路径 | raw列 | cal列 | 样本行数 | 月份数 | 问题 |
|---|---|---|---|---:|---:|---|
| lstm_dim19_h2_rolling18m_seq20_20260304_tushare.json | YES | YES | NO | 864 | 6 | missing_cal_cols:pred_10d_cal,pred_5d_cal |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_tushare.json | YES | YES | YES | 864 | 6 | OK |
