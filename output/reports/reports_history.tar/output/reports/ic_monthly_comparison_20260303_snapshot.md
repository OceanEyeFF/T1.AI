# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- 公共 OOS 月份数: 9

| 报告 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---:|---:|---:|---:|---:|---|
| lstm_dim19_h2_rolling18m_seq20_20260303.json | 0.0603 | 0.0564 | 33.3% | -0.2143 | 2 | FAIL |
| lstm_dim19_h2_rolling18m_seq30_20260303.json | 0.0043 | 0.0656 | 33.3% | -0.2090 | 5 | FAIL |
| lstm_dim19_rolling18m_horizoncal_20260303.json | 0.0672 | 0.1100 | 33.3% | -0.2174 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_20260303.json | 0.0672 | 0.1100 | 33.3% | -0.2174 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260303.json | 0.0672 | 0.1100 | 33.3% | -0.2174 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq40_20260303.json | 0.0495 | 0.0747 | 33.3% | -0.1670 | 3 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq60_20260303.json | 0.0394 | 0.1385 | 33.3% | -0.2013 | 4 | FAIL |
