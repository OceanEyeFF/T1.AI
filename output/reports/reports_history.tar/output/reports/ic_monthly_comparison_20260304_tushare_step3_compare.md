# IC 统一评估比较

- 指标口径: raw
- 月度口径: raw
- daily-CS 使用: 2/2 份报告
- 公共 OOS 月份数: 6

| 报告 | 口径来源 | mean(IC_5_10) | mean(RankIC_5_10) | 月胜率 | 最差月 | 连续负月 | 门禁 |
|---|---|---:|---:|---:|---:|---:|---|
| lstm_dim19_h2_rolling18m_seq20_20260304_tushare.json | daily_cs | 0.0029 | -0.0382 | 66.7% | -0.3233 | 2 | FAIL |
| lstm_dim19_rolling18m_horizoncal_consensus_seq20_20260304_tushare.json | daily_cs | -0.0774 | -0.1014 | 33.3% | -0.3733 | 4 | FAIL |
